var app = angular.module("app" , ["ngAnimate", "dndLists", "xeditable"])

app.run(function(editableOptions) {
  editableOptions.theme = 'bs3'; // bootstrap3 theme. Can be also 'bs2', 'default'
});

function SortableCTRL($scope) {
   
    var sortableEle;

    // $scope.models = {
    //   selected: null, 
    //   lists: {"sortableArray" : ['One' , 'Two' , 'Three' , 'Four' , 'Five']
    //     "trashCan": []}
    // }
    // }
    
    $scope.sortableArray = [
 		'One' , 'Two' , 'Three' , 'Four' , 'Five'
    ];

    $scope.trashcan = [];
    
    $scope.add = function() {
        // $scope.sortableArray.push('New Agenda Item #'+$scope.sortableArray.length);
        $scope.sortableArray.push($scope.AgendaText);
        $scope.AgendaText = '';
    }
        
    sortableEle = $('#sortable').sortable({
        start: $scope.dragStart,
        update: $scope.dragEnd
    });

    $scope.editItem = function(item) {
        angular.element(document.getElementById("modal")).scope().item = item;
    };

    $scope.class_status = 1;
    
    $scope.toggleSingleClass = function() {

        $scope.class_status = !$scope.class_status;

    };

    $scope.models = {
        selected: null,
        lists: {"A": [], "B": []}
    };

}; // end of SortableCTRL 

app.directive('showonhover', function() {
      return {
         link : function(scope, element, attrs) {
            element.bind('mouseenter', function() {
                element.addClass('dottedline');
            });
            element.bind('mouseleave', function() {
                 element.removeClass('dottedline');
            });
       }
   };
});

console.dir();

 // app.directive('draggable', function() {
 //    return function(scope, element) {
 //            // this gives us the native JS object
 //        var el = element[0];

 //        el.draggable = true;

 //        el.addEventListener(
 //            'dragstart',
 //            function(e) {
 //                e.dataTransfer.effectAllowed = 'move';
 //                e.dataTransfer.setData('Text', this.id);
 //                this.classList.add('drag');
 //                return false;
 //            },
 //            false
 //        );

 //        el.addEventListener(
 //            'dragend',
 //            function(e) {
 //                this.classList.remove('drag');
 //                return false;
 //            },
 //            false
 //        );
 //      }

 //      }
 //    });