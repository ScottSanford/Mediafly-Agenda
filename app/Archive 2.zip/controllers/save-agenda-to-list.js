angular.module('agendaApp')

	.controller('SaveAgendaCtrl', function($scope, $location, $routeParams, $q, MflyDataService, EditControlsService, InitAgendaService, NewAgendaService, DialogService, mfly){

        if ($routeParams.id === undefined) {
            $scope.newAgenda = {
                title: $scope.newAgenda.title
            }
        } else {
            for (var i = 0; i < InitAgendaService.data.length; i++) {
                if ($routeParams.id === InitAgendaService.data[i].id) {
                    $scope.title = InitAgendaService.data[i].title;         
                }
            }
        }
        $scope.agendaList = InitAgendaService.data;

        $scope.saveAgendatoList = function() {
            if ($routeParams.id === undefined) {

                EditControlsService.saveAndPushToAgendaList($scope.newAgenda.title, NewAgendaService.items);
                DialogService.createDialogBox('partials/load-agenda.html', 'ngdialog-theme-plain', 'LoadAgendaCtrl');

                // save to mfly App
                var savedAgendaList = InitAgendaService.data;
                mfly.putValue('agendaList', JSON.stringify(savedAgendaList));


            } else {

                for (var i = 0; i < InitAgendaService.data.length; i++) {
                    if ($routeParams.id === InitAgendaService.data[i].id) {
                        EditControlsService.saveAndPushToAgendaList($scope.newAgenda.title, InitAgendaService.data[i].items);
                        DialogService.createDialogBox('partials/load-agenda.html', 'ngdialog-theme-plain', 'LoadAgendaCtrl');

                        // save to mfly App
                        useNamespace = typeof useNamespace !== 'undefined' ? useNamespace : true;
                        MflyDataService.save(InitAgendaService.data[i].id,InitAgendaService.data[i], useNamespace);
                        // MflyDataService.save();
                    }
                }
            }
        	console.log("InitAgendaService.data :: " , InitAgendaService.data);
        	$scope.closeThisDialog();
        }

        $scope.closeDialogBox = function() {
            $scope.closeThisDialog();
        }

	});