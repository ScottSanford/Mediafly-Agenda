angular.module('agendaApp')

	.controller('agendaListCtrl', function($scope, $filter, $rootScope, $routeParams, $location, $window, $route, mfly, MflyDataService, EditControlsService, InitAgendaService, NewAgendaService, DialogService, ngDialog){

        function initalizeAgenda() {
            $scope.newAgenda = {
                title: NewAgendaService.title
            }
            $scope.agendaList = NewAgendaService.items;
            $routeParams.id = undefined;
        }

        initalizeAgenda();

        // when user chooses a 'Saved Agenda' from the List
        mfly.getValue('agendaList').then(function(response){
            var data = JSON.parse(response);
            console.log(data);

            for (var i = 0; i < data.length; i++) {
                if ($routeParams.id === undefined) {
                    initalizeAgenda();
                } else if ($routeParams.id === data[i].id) {
                    $scope.newAgenda = {
                        title: data[i].title
                    }
                    $scope.agendaList = data[i].items[i].itemName;              
                }
            }
        });

        $scope.openMenu = function() {
            $scope.showActions = true;
        }

        // new agenda
        $rootScope.createNewAgenda = function() {
            initalizeAgenda();
            // $window.location.href = 'http://127.0.0.1:8000/';
            $window.location.href = 'mfly://';
        }

        // load button
        $rootScope.savedAgendasDialogBox = function() {
            DialogService.createDialogBox('partials/saved-agendas.html', 'ngdialog-theme-plain custom-width', 'SavedAgendasCtrl');
        }

        $scope.loadAgendaFromTemplate = function() {
            MflyDataService.load('agendaList', false).then(function(result){
                console.log(result.data);
                $scope.agendaList = result.data;
                $scope.saveAgenda();
            });
            MflyDataService.load('agendaTitle', false).then(function(result){
                $scope.agenda.title = result.data;
            })
        }

        // Edit Controls (add, save, edit, delete)

        $scope.addDialogBox = function() {
            DialogService.createDialogBox('partials/add-item.html', 'ngdialog-theme-plain', 'AddAgendaItemCtrl');
        };

        $scope.editDialogBox = function(item){
             DialogService.createDialogBox('partials/edit-text.html', 'ngdialog-theme-plain', 'EditTextCtrl', $scope);
        };

        $scope.deleteDialogBox = function(item) { 
            console.log(item);

            var newAgendaItemArray = NewAgendaService.items;

            $scope.delagendaList = item;

            if (areItemsChecked(newAgendaItemArray)) {

                ngDialog.openConfirm({
                    template: 'partials/delete-items.html', 
                    className: 'ngdialog-theme-plain', 
                    scope: $scope, 
                    controller: function($scope) {
                        $scope.closeDialogBox = function() {
                            console.log('clicked');
                            $scope.closeThisDialog();
                        }
                    }
                });

                $scope.deleteItems = function() {
                    $scope.agendaList = $filter('filter')($scope.agendaList, {checked: false});
                    console.log($scope.agendaList);
                    ngDialog.closeAll();
                }


            }      


        };

        $scope.closeDialogBox = function() {
            console.log('clicked');
            $scope.closeThisDialog();
        }

        function areItemsChecked(array) {
            for (var i = 0; i < array.length; i++) {
                if (array[i].checked) {
                    return true;
                }
            }
            return false;
        }

        $scope.saveDialogBox = function() { 
                DialogService.createDialogBox('partials/save-load-agenda.html', 'ngdialog-theme-plain', 'SaveAgendaCtrl', $scope);
        };

        // AGENDA MENU END
        $scope.saveAndCloseEdit = function() {
            saveAgendatotemplate();
        }

        // trash dialog 

        // remove item from agenda list
        $scope.removeItem = function(index) {
            // var item = $scope.agendaList[index];
            $scope.agendaList.splice(index, 1);
        }


        // extra scopes
        // open menu 
        /** Save the agenda with AJAX.**/
        $scope.saveAgenda = function(useNamespace) {
            useNamespace = typeof useNamespace !== 'undefined' ? useNamespace : true;
            MflyDataService.save('agendaList', JSON.stringify($scope.agendaList), useNamespace);
        }

        // save button
        $scope.saveAgendaToTemplate = function() {
            MflyDataService.save('agendaList', JSON.stringify($scope.agendaList), false);         
            MflyDataService.save('agendaTitle', $scope.agenda.title, false);         
        }


	})