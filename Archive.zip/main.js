angular.module('agendaApp',[
		'ngRoute', 
		'ngAnimate', 
		'ngTouch', 
		'angular-growl',
		'hmTouchEvents',
		'Mediafly.services', 
		'ngDialog',
		'angular-sortable-view', 
		'ui.sortable'
	])

	.config(function ($routeProvider, $compileProvider, growlProvider) {
			$compileProvider.imgSrcSanitizationWhitelist(/^(mfly:\/\/data\/image|http:\/\/)/);	        
	        $routeProvider
	        	.when('/', {
	        		templateUrl: "partials/agenda-list.html"    		
	        	})
	            .otherwise({
	                redirectTo: '/'
	            });
	        growlProvider.globalTimeToLive(3000);
	        growlProvider.globalDisableCountDown(true);
	})

