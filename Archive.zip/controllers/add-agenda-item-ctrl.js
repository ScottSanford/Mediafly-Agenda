angular.module('agendaApp')

	.controller('AddAgendaItemCtrl', function($scope, mfly, MflyDataService, growl, ngDialog){
		console.log('AddAgendaItemCtrl connected!');
	});